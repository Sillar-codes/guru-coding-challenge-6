"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.corsOption = exports.TABLE_NAME = exports.USER_POOL_CLIENT_ID = exports.USER_POOL_ID = exports.REGION = void 0;
const dotenv_1 = require("dotenv");
(0, dotenv_1.configDotenv)();
exports.REGION = process.env.AWS_REGION || '';
exports.USER_POOL_ID = process.env.USER_POOL_ID || '';
exports.USER_POOL_CLIENT_ID = process.env.USER_POOL_CLIENT_ID || '';
exports.TABLE_NAME = process.env.TABLE_NAME || '';
exports.corsOption = {
    'Access-Control-Allow-Origin': '*'
};
