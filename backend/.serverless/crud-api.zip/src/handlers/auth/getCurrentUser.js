"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const apiGateway_1 = require("../../libs/apiGateway");
const config_1 = require("../../config");
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: config_1.REGION
});
const handler = async (event) => {
    try {
        const userId = event.requestContext.authorizer?.claims?.sub;
        const email = event.requestContext.authorizer?.claims?.email;
        const name = event.requestContext.authorizer?.claims?.name;
        if (!userId) {
            return (0, apiGateway_1.errorResponse)('Unauthorized', 'User not authenticated', 401);
        }
        // Get additional user info from Cognito
        const getUserCommand = new client_cognito_identity_provider_1.AdminGetUserCommand({
            UserPoolId: config_1.USER_POOL_ID,
            Username: email,
        });
        const userInfo = await cognitoClient.send(getUserCommand);
        const user = {
            userId,
            email: email || '',
            name: name || '',
            emailVerified: userInfo.UserAttributes?.find(attr => attr.Name === 'email_verified')?.Value === 'true',
        };
        return (0, apiGateway_1.successResponse)(user);
    }
    catch (error) {
        console.error('Error getting current user:', error);
        return (0, apiGateway_1.errorResponse)('InternalError', 'Failed to get user information');
    }
};
exports.handler = handler;
