"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const apiGateway_1 = require("../../libs/apiGateway");
const config_1 = require("../../config");
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: config_1.REGION
});
const handler = async (event) => {
    try {
        if (!event.body) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Request body is required', 400);
        }
        const request = JSON.parse(event.body);
        if (!request.email || !request.password) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Email and password are required', 400);
        }
        const authCommand = new client_cognito_identity_provider_1.AdminInitiateAuthCommand({
            UserPoolId: config_1.USER_POOL_ID,
            ClientId: config_1.USER_POOL_CLIENT_ID,
            AuthFlow: 'ADMIN_NO_SRP_AUTH',
            AuthParameters: {
                USERNAME: request.email,
                PASSWORD: request.password,
            },
        });
        const response = await cognitoClient.send(authCommand);
        if (!response.AuthenticationResult) {
            return (0, apiGateway_1.errorResponse)('AuthenticationError', 'Authentication failed', 401);
        }
        const authResponse = {
            accessToken: response.AuthenticationResult.AccessToken,
            refreshToken: response.AuthenticationResult.RefreshToken,
            idToken: response.AuthenticationResult.IdToken,
            expiresIn: response.AuthenticationResult.ExpiresIn,
            tokenType: response.AuthenticationResult.TokenType,
        };
        return (0, apiGateway_1.successResponse)(authResponse);
    }
    catch (error) {
        const err = error;
        console.error('Error signing in user:', error);
        if (err.name === 'NotAuthorizedException' || err.name === 'UserNotFoundException') {
            return (0, apiGateway_1.errorResponse)('AuthenticationError', 'Invalid email or password', 401);
        }
        return (0, apiGateway_1.errorResponse)('InternalError', 'Failed to authenticate user');
    }
};
exports.handler = handler;
