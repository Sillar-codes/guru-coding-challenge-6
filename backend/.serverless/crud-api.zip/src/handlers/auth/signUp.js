"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const apiGateway_1 = require("../../libs/apiGateway");
const config_1 = require("../../config");
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: config_1.REGION
});
const handler = async (event) => {
    try {
        if (!event.body) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Request body is required', 400);
        }
        const request = JSON.parse(event.body);
        if (!request.email || !request.password || !request.name) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Email, password, and name are required', 400);
        }
        if (request.password.length < 8) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Password must be at least 8 characters long', 400);
        }
        const createUserCommand = new client_cognito_identity_provider_1.AdminCreateUserCommand({
            UserPoolId: config_1.USER_POOL_ID,
            Username: request.email,
            UserAttributes: [
                { Name: 'email', Value: request.email },
                { Name: 'name', Value: request.name },
                { Name: 'email_verified', Value: 'true' }
            ],
            MessageAction: 'SUPPRESS',
            TemporaryPassword: request.password,
        });
        await cognitoClient.send(createUserCommand);
        const setPasswordCommand = new client_cognito_identity_provider_1.AdminSetUserPasswordCommand({
            UserPoolId: config_1.USER_POOL_ID,
            Username: request.email,
            Password: request.password,
            Permanent: true,
        });
        await cognitoClient.send(setPasswordCommand);
        return (0, apiGateway_1.successResponse)({
            message: 'User created successfully',
            user: {
                email: request.email,
                name: request.name
            }
        }, 201);
    }
    catch (error) {
        const err = error;
        console.error('Error signing up user:', error);
        if (err.name === 'UsernameExistsException') {
            return (0, apiGateway_1.errorResponse)('UsernameExists', 'User with this email already exists', 400);
        }
        return (0, apiGateway_1.errorResponse)('InternalError', err.message);
    }
};
exports.handler = handler;
