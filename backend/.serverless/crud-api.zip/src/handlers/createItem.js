"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const uuid_1 = require("uuid");
const dynamodb_1 = require("../utils/dynamodb");
const handler = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Request body is required' }),
            };
        }
        const request = JSON.parse(event.body);
        // Validation
        if (!request.name || !request.description || !request.price || !request.category) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'All fields are required' }),
            };
        }
        const itemId = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const newItem = {
            itemId,
            name: request.name,
            description: request.description,
            price: request.price,
            category: request.category,
            createdAt: timestamp,
            updatedAt: timestamp,
        };
        await dynamodb_1.ddbDocClient.send(new lib_dynamodb_1.PutCommand({
            TableName: process.env.TABLE_NAME,
            Item: newItem,
        }));
        return {
            statusCode: 201,
            body: JSON.stringify({
                statusCode: 201,
                body: newItem,
                message: 'Item created successfully'
            }),
        };
    }
    catch (error) {
        console.error('Error creating item:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Internal server error',
                statusCode: 500,
                body: null
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=createItem.js.map