"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamodb_1 = require("../utils/dynamodb");
const handler = async (event) => {
    try {
        const itemId = event.pathParameters?.id;
        if (!itemId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Item ID is required' }),
            };
        }
        const command = new lib_dynamodb_1.GetCommand({
            TableName: process.env.TABLE_NAME,
            Key: { itemId },
        });
        const result = await dynamodb_1.ddbDocClient.send(command);
        if (!result.Item) {
            return {
                statusCode: 404,
                body: JSON.stringify({ message: 'Item not found' }),
            };
        }
        return {
            statusCode: 200,
            body: JSON.stringify({
                statusCode: 200,
                body: result.Item,
                message: 'Item retrieved successfully'
            }),
        };
    }
    catch (error) {
        console.error('Error retrieving item:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Internal server error',
                statusCode: 500,
                body: null
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=getItem.js.map