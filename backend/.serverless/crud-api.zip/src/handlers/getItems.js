"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamodb_1 = require("../utils/dynamodb");
const handler = async (event) => {
    try {
        const command = new lib_dynamodb_1.ScanCommand({
            TableName: process.env.TABLE_NAME,
        });
        const result = await dynamodb_1.ddbDocClient.send(command);
        const items = result.Items || [];
        return {
            statusCode: 200,
            body: JSON.stringify({
                statusCode: 200,
                body: items,
                message: 'Items retrieved successfully'
            }),
        };
    }
    catch (error) {
        console.error('Error retrieving items:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Internal server error',
                statusCode: 500,
                body: null
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=getItems.js.map