"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const uuid_1 = require("uuid");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamoDB_1 = require("../../libs/dynamoDB");
const apiGateway_1 = require("../../libs/apiGateway");
const config_1 = require("../../config");
const handler = async (event) => {
    try {
        const userId = event.requestContext.authorizer?.claims?.sub;
        if (!userId) {
            return (0, apiGateway_1.errorResponse)('Unauthorized', 'User not authenticated', 401);
        }
        if (!event.body) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Request body is required', 400);
        }
        const request = JSON.parse(event.body);
        if (!request.name || !request.description || !request.price || !request.category) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'All fields are required', 400);
        }
        if (request.price <= 0) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Price must be greater than 0', 400);
        }
        const itemId = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const newItem = {
            itemId,
            userId,
            name: request.name,
            description: request.description,
            price: request.price,
            category: request.category,
            createdAt: timestamp,
            updatedAt: timestamp,
        };
        await dynamoDB_1.ddbDocClient.send(new lib_dynamodb_1.PutCommand({
            TableName: config_1.TABLE_NAME,
            Item: newItem,
        }));
        return (0, apiGateway_1.successResponse)(newItem, 201);
    }
    catch (error) {
        console.error('Error creating item:', error);
        return (0, apiGateway_1.errorResponse)('InternalError', error.message);
    }
};
exports.handler = handler;
