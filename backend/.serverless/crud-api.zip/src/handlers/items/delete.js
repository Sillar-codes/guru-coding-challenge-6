"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamoDB_1 = require("../../libs/dynamoDB");
const apiGateway_1 = require("../../libs/apiGateway");
const config_1 = require("../../config");
const handler = async (event) => {
    try {
        const userId = event.requestContext.authorizer?.claims?.sub;
        if (!userId) {
            return (0, apiGateway_1.errorResponse)('Unauthorized', 'User not authenticated', 401);
        }
        const itemId = event.pathParameters?.id;
        if (!itemId) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Item ID is required', 400);
        }
        // First, verify the item exists and belongs to the user
        const getResult = await dynamoDB_1.ddbDocClient.send(new lib_dynamodb_1.GetCommand({
            TableName: config_1.TABLE_NAME,
            Key: { itemId },
        }));
        if (!getResult.Item) {
            return (0, apiGateway_1.errorResponse)('NotFound', 'Item not found', 404);
        }
        const existingItem = getResult.Item;
        if (existingItem.userId !== userId) {
            return (0, apiGateway_1.errorResponse)('Forbidden', 'Access denied to this item', 403);
        }
        await dynamoDB_1.ddbDocClient.send(new lib_dynamodb_1.DeleteCommand({
            TableName: config_1.TABLE_NAME,
            Key: { itemId },
        }));
        return (0, apiGateway_1.successResponse)({
            message: 'Item deleted successfully',
            itemId
        });
    }
    catch (error) {
        console.error('Error deleting item:', error);
        return (0, apiGateway_1.errorResponse)('InternalError', error.message);
    }
};
exports.handler = handler;
