"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamoDB_1 = require("../../libs/dynamoDB");
const apiGateway_1 = require("../../libs/apiGateway");
const config_1 = require("../../config");
const handler = async (event) => {
    try {
        const userId = event.requestContext.authorizer?.claims?.sub;
        if (!userId) {
            return (0, apiGateway_1.errorResponse)('Unauthorized', 'User not authenticated', 401);
        }
        const result = await dynamoDB_1.ddbDocClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: config_1.TABLE_NAME,
            IndexName: 'userId-index',
            KeyConditionExpression: 'userId = :userId',
            ExpressionAttributeValues: {
                ':userId': userId,
            },
        }));
        return (0, apiGateway_1.successResponse)(result.Items || []);
    }
    catch (error) {
        console.error('Error listing items:', error);
        return (0, apiGateway_1.errorResponse)('InternalError', error.message);
    }
};
exports.handler = handler;
