"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamoDB_1 = require("../../libs/dynamoDB");
const apiGateway_1 = require("../../libs/apiGateway");
const config_1 = require("../../config");
const handler = async (event) => {
    try {
        const userId = event.requestContext.authorizer?.claims?.sub;
        if (!userId) {
            return (0, apiGateway_1.errorResponse)('Unauthorized', 'User not authenticated', 401);
        }
        const itemId = event.pathParameters?.id;
        if (!itemId) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Item ID is required', 400);
        }
        if (!event.body) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Request body is required', 400);
        }
        // First, verify the item exists and belongs to the user
        const getResult = await dynamoDB_1.ddbDocClient.send(new lib_dynamodb_1.GetCommand({
            TableName: config_1.TABLE_NAME,
            Key: { itemId },
        }));
        if (!getResult.Item) {
            return (0, apiGateway_1.errorResponse)('NotFound', 'Item not found', 404);
        }
        const existingItem = getResult.Item;
        if (existingItem.userId !== userId) {
            return (0, apiGateway_1.errorResponse)('Forbidden', 'Access denied to this item', 403);
        }
        const request = JSON.parse(event.body);
        // Check if at least one field is provided
        if (!request.name && !request.description && !request.price && !request.category) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'At least one field must be provided for update', 400);
        }
        if (request.price !== undefined && request.price <= 0) {
            return (0, apiGateway_1.errorResponse)('ValidationError', 'Price must be greater than 0', 400);
        }
        const updateExpression = [];
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        if (request.name) {
            updateExpression.push('#name = :name');
            expressionAttributeNames['#name'] = 'name';
            expressionAttributeValues[':name'] = request.name;
        }
        if (request.description) {
            updateExpression.push('#description = :description');
            expressionAttributeNames['#description'] = 'description';
            expressionAttributeValues[':description'] = request.description;
        }
        if (request.price !== undefined) {
            updateExpression.push('#price = :price');
            expressionAttributeNames['#price'] = 'price';
            expressionAttributeValues[':price'] = request.price;
        }
        if (request.category) {
            updateExpression.push('#category = :category');
            expressionAttributeNames['#category'] = 'category';
            expressionAttributeValues[':category'] = request.category;
        }
        updateExpression.push('#updatedAt = :updatedAt');
        expressionAttributeNames['#updatedAt'] = 'updatedAt';
        expressionAttributeValues[':updatedAt'] = new Date().toISOString();
        const result = await dynamoDB_1.ddbDocClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: config_1.TABLE_NAME,
            Key: { itemId },
            UpdateExpression: `SET ${updateExpression.join(', ')}`,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW',
        }));
        return (0, apiGateway_1.successResponse)(result.Attributes);
    }
    catch (error) {
        console.error('Error updating item:', error);
        return (0, apiGateway_1.errorResponse)('InternalError', 'Failed to update item');
    }
};
exports.handler = handler;
