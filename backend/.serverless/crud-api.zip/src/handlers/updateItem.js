"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamodb_1 = require("../utils/dynamodb");
const handler = async (event) => {
    try {
        const itemId = event.pathParameters?.id;
        if (!itemId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Item ID is required' }),
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Request body is required' }),
            };
        }
        const updates = JSON.parse(event.body);
        const timestamp = new Date().toISOString();
        const updateExpression = [];
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        Object.keys(updates).forEach(key => {
            if (updates[key] !== undefined) {
                updateExpression.push(`#${key} = :${key}`);
                expressionAttributeNames[`#${key}`] = key;
                expressionAttributeValues[`:${key}`] = updates[key];
            }
        });
        if (updateExpression.length === 0) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'No valid fields to update' }),
            };
        }
        updateExpression.push('#updatedAt = :updatedAt');
        expressionAttributeNames['#updatedAt'] = 'updatedAt';
        expressionAttributeValues[':updatedAt'] = timestamp;
        const command = new lib_dynamodb_1.UpdateCommand({
            TableName: process.env.TABLE_NAME,
            Key: { itemId },
            UpdateExpression: `SET ${updateExpression.join(', ')}`,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW',
        });
        const result = await dynamodb_1.ddbDocClient.send(command);
        return {
            statusCode: 200,
            body: JSON.stringify({
                statusCode: 200,
                body: result.Attributes,
                message: 'Item updated successfully'
            }),
        };
    }
    catch (error) {
        console.error('Error updating item:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Internal server error',
                statusCode: 500,
                body: null
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=updateItem.js.map